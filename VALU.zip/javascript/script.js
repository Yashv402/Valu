// HOVER EFFECT ON FEATURES----------------------------------------------------------->

const handleOnMouseMove= e =>{
    const{currentTarget :target}=e;

    const rect =target.getBoundingClientRect(),
    x=e.clientX-rect.left;
    y=e.clientY-rect.top;

    target.style.setProperty("--mouse-x", `${x}px`);
    target.style.setProperty("--mouse-y", `${y}px`);
    
}

for(const card of document.querySelectorAll(".card")){
    card.onmousemove = e => handleOnMouseMove(e);
}
    



// ABOUT PAGE----------------------------------------------------------->

const container = document.querySelector(".container");
const sections = gsap.utils.toArray(".container section");
const texts = gsap.utils.toArray(".anim");
const mask = document.querySelector(".mask");

let scrollTween = gsap.to(sections, {
  xPercent: -100 * (sections.length - 1),
  ease: "none",
  scrollTrigger: {
    trigger: ".container",
    pin: true,
    scrub: 1,
    end: "+=3000",
    //snap: 1 / (sections.length - 1),
    // markers: true,
  }
});

console.log(1 / (sections.length - 1))

//Progress bar animation

gsap.to(mask, {
  width: "100%",
  scrollTrigger: {
    trigger: ".wrapper",
    start: "top left",
    scrub: 1
  }
});

// whizz around the sections
sections.forEach((section) => {
  // grab the scoped text
  let text = section.querySelectorAll(".anim");
  
  // bump out if there's no items to animate
  if(text.length === 0)  return 
  
  // do a little stagger
  gsap.from(text, {
    y: -130,
    opacity: 0,
    duration: 2,
    ease: "elastic",
    stagger: 0.1,
    scrollTrigger: {
      trigger: section,
      containerAnimation: scrollTween,
      start: "left center",
      // markers: true
    }
  });
});




// OUR TEAM PAGE----------------------------------------------------------->
$(function () {
  "use strict";
  function accordion() {
    $(".accordion .accordion__item").on("click", function () {
      const timeAnim = 400;
      $(".accordion .accordion__item").removeClass("active").css({ "pointer-events": "auto" });
      $(this).addClass("active").css({ "pointer-events": "none" });
      $(".accordion .accordion__header").next().slideUp(timeAnim);
      $(this).find(".accordion__header").next().slideDown(timeAnim);

      $(".accord_img").removeClass("active");
      let id = $(this).data("id");
      $("#" + id + "-img").addClass("active");
    });
  }
  accordion();

  function cursor() {
    //cursor coord
    $(window).on("mousemove", function (e) {
      let x = e.clientX;
      let y = e.clientY;
      $(".cursor").css({ left: x + "px", top: y + "px" });
    });
    $(".accordion__item, h1, h3").each(function () {
      $(this).mouseenter(function () {
        $(".cursor").addClass("active");
      });

      $(this).mouseleave(function () {
        $(".cursor").removeClass("active");
      });
    });
    
  }
  cursor();
});
